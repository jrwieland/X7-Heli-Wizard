Individual model files for the Backup/Restore model features go here, as well as model note text files.
